﻿//http://sharepointbrian.com/2013/07/sharepoint-2013-check-user-in-spgroup-using-rest-in-javascript/
///<reference path="ASD_Constant.js" />
///<reference path="ASD_Object.js" />
var ASD_Authorization = {
    displaySections: function (REQStatus) {

        currentLoginPermissionLevel.populateData();

        switch (REQStatus) {
            case ASD_Enum_REQ_STATUS.DRAFT:
            case ASD_Enum_REQ_STATUS.INCOMPLETE:
            case ASD_Enum_REQ_STATUS.REJECTED:
                //alert("draft incomplete rejected");
                //IF REQStatus is DRAFT/InComplete/Rejected, 
                //External visible to: Submitting Office + creator, AO and COR
                if (currentLoginPermissionLevel.BelongsToSubmittingOffice || currentLoginPermissionLevel.IsCreator || currentLoginPermissionLevel.isAO || currentLoginPermissionLevel.isCOR) {
                    this.makeSectionsVisible(true, true, false);
                }
                else {
                    alert("you don't have view permission");
                }
                break;
            case ASD_Enum_REQ_STATUS.SUBMITTED:
                //do somthing
                //external section visible to Submitting Offce, creator, AO and COR
                if (currentLoginPermissionLevel.BelongsToSubmittingOffice || currentLoginPermissionLevel.IsCreator || currentLoginPermissionLevel.isAO || currentLoginPermissionLevel.isCOR) {
                    this.makeSectionsVisible(true, true, false);
                } else {
                    alert("you don't have view permission");
                }

                break;
            case ASD_Enum_REQ_STATUS.AO_APPROVED:
                //do somthing
                //extenal section visible to Submitting Offce + creator, AO and COR, CS group
                //external and internal section visible to CO group
                if (currentLoginPermissionLevel.BelongsToCOGroup) {
                    this.makeSectionsVisible(true, true, true);
                } else {
                    if (currentLoginPermissionLevel.BelongsToSubmittingOffice || currentLoginPermissionLevel.IsCreator || currentLoginPermissionLevel.isAO || currentLoginPermissionLevel.isCOR) {
                        this.makeSectionsVisible(true, true, false);
                    } else {
                        alert("you don't have view permission");
                    }
                }

                break;
            case ASD_Enum_REQ_STATUS.IN_REVIEW:
                //do somthing
                //extenal section visible to Submitting Offce + creator, AO and COR
                //external and internal section visible to CO group
                if (currentLoginPermissionLevel.BelongsToCOGroup) {
                    this.makeSectionsVisible(true, true, true);
                } else {
                    if (currentLoginPermissionLevel.BelongsToSubmittingOffice || currentLoginPermissionLevel.IsCreator || currentLoginPermissionLevel.isAO || currentLoginPermissionLevel.isCOR) {
                        this.makeSectionsVisible(true, true, false);
                    } else {
                        alert("you don't have view permission");
                    }
                }
                break;
            case ASD_Enum_REQ_STATUS.ASSIGNED:
                //do somthing
                //extenal section visible to Submitting Offce + creator, AO and COR
                //external and internal section visible to CO group, CS
                if (currentLoginPermissionLevel.BelongsToCOGroup || currentLoginPermissionLevel.isCS) {                    
                    this.makeSectionsVisible(true, true, true);
                } else {
                    if (currentLoginPermissionLevel.BelongsToSubmittingOffice || currentLoginPermissionLevel.IsCreator || currentLoginPermissionLevel.isAO ||
                        currentLoginPermissionLevel.isCOR) {
                        this.makeSectionsVisible(true, true, false);
                    } else {
                        alert("you don't have view permission");
                    }
                }
                break;                
            case ASD_Enum_REQ_STATUS.REQUIREMENT_CANCEL:
            case ASD_Enum_REQ_STATUS.AWARD:
            case ASD_Enum_REQ_STATUS.CANCEL_BY_REQUESTOR:
                //do somthing
                //extenal section visible to Submitting Offce, creator, AO,COR, End User
                //internal and external section visible to CS group, CO
                if (currentLoginPermissionLevel.BelongsToCOGroup || currentLoginPermissionLevel.isCS) {
                    this.makeSectionsVisible(true, true, true);
                } else {
                    if (currentLoginPermissionLevel.BelongsToSubmittingOffice || currentLoginPermissionLevel.IsCreator || currentLoginPermissionLevel.isAO ||
                        currentLoginPermissionLevel.isCOR || currentLoginPermissionLevel.BelongsToEndUserGroup) {
                        this.makeSectionsVisible(true, true, false);
                    } else {
                        alert("you don't have view permission");
                    }
                }
                break;
            default:
                alert("Unknown REQ Status");
        }



    },
    makeSectionsVisible: function (headerSectionVisible, ExternalSectionVisible, InternalSectionVisible) {
        if (headerSectionVisible) {
            jQuery("#headerSection").removeClass("invisible");
        }

        if (ExternalSectionVisible) {
            jQuery("#externalSection").removeClass("invisible");
        }

        if (InternalSectionVisible) {
            jQuery("#internalSection").removeClass("invisible");
        }

    },

};