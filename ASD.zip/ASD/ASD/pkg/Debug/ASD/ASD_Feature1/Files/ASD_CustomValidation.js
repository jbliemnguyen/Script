﻿/*jshint -W117 */
///<reference path="ASD_Constant.js" />
var ASD_CustomValidation = {
    //Determine if people picker have a valid value, return false if empty or invalid value
    isPeoplePickerHasValue: function (controlToBeValidated) {
        //html code of the People Picker
        //"<div title=\"COR\" class=\"sp-peoplepicker-topLevel\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker\" SPClientPeoplePicker=\"true\"><input name=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_HiddenInput\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_HiddenInput\" type=\"hidden\" value='[{\"Key\":\"i:0#.w|adferc\\\\lnngd\",\"DisplayText\":\"Liem Nguyen\",\"IsResolved\":true,\"Description\":\"i:0#.w|adferc\\\\lnngd\",\"EntityType\":\"\",\"EntityGroupName\":\"\",\"HierarchyIdentifier\":null,\"EntityData\":{\"Email\":\"Liem.Nguyen@ferc.gov\",\"Department\":\"General Dynamics Information Technology\",\"SPUserID\":\"1\",\"AccountName\":\"i:0#.w|adferc\\\\lnngd\",\"PrincipalType\":\"User\"},\"MultipleMatches\":[],\"ProviderName\":\"\",\"ProviderDisplayName\":\"\",\"Resolved\":true}]'><div class=\"sp-peoplepicker-autoFillContainer\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_AutoFillDiv\" style=\"left: -1px; top: 26px;\" InputElementId=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_EditorInput\"></div><span class=\"sp-peoplepicker-initialHelpText ms-helperText\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_InitialHelpText\" style=\"display: none;\">Enter a name or email address...</span><img class=\"sp-peoplepicker-waitImg\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_WaitImage\" alt=\"This animation indicates the operation is in progress. Click to remove this animated image.\" src=\"/_layouts/15/images/gears_anv4.gif?rev=23\"><span class=\"sp-peoplepicker-resolveList\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePi
        //var controlToBeValidated = jQuery("div[title='" + displayFieldName + "']").find("input:first");

        if (controlToBeValidated) {
            var controlValue = controlToBeValidated.attr("value");
            if (controlValue) {
                if (controlValue.indexOf('\"IsResolved\":true') > -1) {
                    return true;
                }
            }
        }
        return false;
    },

    //*********************************************************************
    //Determine if textbox is match regular expression input,if isRequired = true,  return false if empty or invalid value
    //If isRequired = false, return false if there is value and value match, otherwise return false
    isTextBoxMatchValue: function (controlToBeValidated, Regex) {
        if (controlToBeValidated) {
            var controlValue = controlToBeValidated.val();
            return RegExp(Regex).test(controlValue);
        }

        return false;

    },
    //*********************************************************************
    //Determine if textbox has value on it
    isTextBoxHasValue: function (controlToBeValidated) {
        if (controlToBeValidated) {
            var controlValue = controlToBeValidated.val();
            if (controlValue) {
                return true;
            }
        }

        return false;

    },
    //*********************************************************************
    isSelectedInDropdownEqual: function (controlToBeValidated, value) {
        //var controlToBeValidated = jQuery("select[title='" + displayFieldName + "']");        
        if (controlToBeValidated) {
            var controlValue = controlToBeValidated.children("option:selected").text();
            if (controlValue) {
                //check if selected value in dropdown have the same value 
                return (controlValue.localeCompare(value) === 0);
            }
        }

        return false;
    },
    //*********************************************************************
    //set the validation result and error message for later display
    setValidationResult: function (controlToBeValidated, isPeoplePicker, isValidated, validationResult, errorMessage) {
        if (isPeoplePicker) {
            //if control is people picker, must set the validation error color on its parent(div) instead of input (because iput does not render -> no color display)
            controlToBeValidated = controlToBeValidated.parent();
        }

        if (!isValidated) {
            validationResult.isValidated = validationResult.isValidated && false;
            validationResult.message = validationResult.message + "<li>" + errorMessage + "</li>";

            if (controlToBeValidated) {
                controlToBeValidated.addClass("invalidatedControl");
            }

        } else {
            if (controlToBeValidated) {
                controlToBeValidated.removeClass("invalidatedControl");
            }
        }
    },
    //*********************************************************************
    validate: function (validationResult) {
        var ifValue = "";
        var isValidated;
        var controlToBeValidated;
        var REQSTATUS = "";
        var Regex = "";

        //Rule 1: if "Is this an IT product/service?" = Yes (Requested/Funded by CIO), then "If Requested/Funded Outside of CIO, Please identify your CIO Point of Contact" is required        
        ifValue = jQuery("select[title='" + ASD__Enum_Field.IS_THIS_AN_IT_PRODUCT_SERVICE + "'] option:selected").text();
        if ((ifValue) && (ifValue.localeCompare(ASD_Enum_FieldChoice.YES_REQUESTED_FUNDED_BY_CIO) === 0))//selected value is "Yes (Requested/Funded by CIO)"
        {
            //"<div title=\"COR\" class=\"sp-peoplepicker-topLevel\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker\" SPClientPeoplePicker=\"true\"><input name=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_HiddenInput\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_HiddenInput\" type=\"hidden\" value='[{\"Key\":\"i:0#.w|adferc\\\\lnngd\",\"DisplayText\":\"Liem Nguyen\",\"IsResolved\":true,\"Description\":\"i:0#.w|adferc\\\\lnngd\",\"EntityType\":\"\",\"EntityGroupName\":\"\",\"HierarchyIdentifier\":null,\"EntityData\":{\"Email\":\"Liem.Nguyen@ferc.gov\",\"Department\":\"General Dynamics Information Technology\",\"SPUserID\":\"1\",\"AccountName\":\"i:0#.w|adferc\\\\lnngd\",\"PrincipalType\":\"User\"},\"MultipleMatches\":[],\"ProviderName\":\"\",\"ProviderDisplayName\":\"\",\"Resolved\":true}]'><div class=\"sp-peoplepicker-autoFillContainer\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_AutoFillDiv\" style=\"left: -1px; top: 26px;\" InputElementId=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_EditorInput\"></div><span class=\"sp-peoplepicker-initialHelpText ms-helperText\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_InitialHelpText\" style=\"display: none;\">Enter a name or email address...</span><img class=\"sp-peoplepicker-waitImg\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePicker_WaitImage\" alt=\"This animation indicates the operation is in progress. Click to remove this animated image.\" src=\"/_layouts/15/images/gears_anv4.gif?rev=23\"><span class=\"sp-peoplepicker-resolveList\" id=\"COR_fcb600dd-1a09-4395-9002-b0341c3aa7d3_$ClientPeoplePi
            controlToBeValidated = jQuery("div[title='" + ASD__Enum_Field.IF_REQUESTED_FUNDED_OUTSIDE_OF_CIO_PLEASE_IDENTIFY_YOUR_CIO_POINT_OF_CONTACT + "']").find("input:first");
            isValidated = ASD_CustomValidation.isPeoplePickerHasValue(controlToBeValidated);
            ASD_CustomValidation.setValidationResult(controlToBeValidated, true, isValidated, validationResult, "If 'Is this an IT product/service?' = Yes (Requested/Funded by CIO), then 'If Requested/Funded Outside of CIO, please identify your CIO Point of Contact' is required");
        }

        //rule 2: If 'Have you requested this product/service before?' is Yes, then 'Previous Contract Number' must have value of 'FERC-abc' and less than 20 alphanumeric characters
        //or
        //'Previous Contract Number' must have value of 'FERC-abc' and less than 20 alphanumeric characters
        ifValue = "";//reset value to avoid carry value from previous rule
        ifValue = jQuery("tr[data-displayname='" + ASD__Enum_Field.HAVE_YOU_REQUESTED_THIS_PRODUCT_SERVICE_BEFORE + "']").find("input:checked").val();

        if (ifValue) {
            isRequired = (ifValue.localeCompare("Yes") === 0);//selected value is "Yes", this field is required

            if (isRequired) {
                Regex = "^(FERC-)[a-zA-Z0-9]{1,15}$";//match FERC-abc123, require to have 'FERC-' and maximum 20 characters
                controlToBeValidated = jQuery("input[title='" + ASD__Enum_Field.PREVIOUS_CONTRACT_NUMBER + "']");
                isValidated = ASD_CustomValidation.isTextBoxMatchValue(controlToBeValidated, Regex);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "If 'Have you requested this product/service before?' is Yes, then 'Previous Contract Number' must have value of 'FERC-abc' and less than 20 alphanumeric characters");

                //rule 2.1: If 'Have you requested this product/service before?' is Yes, then 'Previous Contractor Name' is required                
                controlToBeValidated = jQuery("input[title='" + ASD__Enum_Field.PREVIOUS_CONTRACTOR_NAME + "']");
                isValidated = ASD_CustomValidation.isTextBoxHasValue(controlToBeValidated);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "If 'Have you requested this product/service before?' is Yes, then 'Previous Contractor Name' is required");
            }
            else//format check for previous contract number
            {
                Regex = "^(FERC-)[a-zA-Z0-9]{0,15}$";//match FERC-abc123, require to have 'FERC-' and maximum 20 characters
                controlToBeValidated = jQuery("input[title='" + ASD__Enum_Field.PREVIOUS_CONTRACT_NUMBER + "']");
                isValidated = ASD_CustomValidation.isTextBoxMatchValue(controlToBeValidated, Regex);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "'Previous Contract Number' must have value of 'FERC-abc' and less than or equal 20 alphanumeric characters");
            }

        }

        //rule 3,4,5
        ifValue = "";//reset value to avoid carry value from previous rule
        REQSTATUS = jQuery("input[title='" + ASD__Enum_Field.REQ_STATUS + "']").val();
        if (REQSTATUS) {
            var isBeforeAssignedStatus = (REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.DRAFT) === 0) || (REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.INCOMPLETE) === 0) || (REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.NOT_APPROVED) === 0) || (REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.SUBMITTED) === 0) || (REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.AO_APPROVED) === 0); //status is not in {Draft, Incomplete, Not Approve,Submitted,AO Approve}
            if (!isBeforeAssignedStatus) {//it measn after assigned status
                //rule 3: ASD Action is required from REQ Status is Assigned (REQ Stastus not in {Draft, Incomplete, Not Approve,Submitted,AO Approve })
                //ASD Action is required have value different than "Please Select"          
                controlToBeValidated = jQuery("select[title='" + ASD__Enum_Field.ASD_ACTION + "']");
                isValidated = !ASD_CustomValidation.isSelectedInDropdownEqual(controlToBeValidated, ASD_Enum_FieldChoice.PLEASE_SELECT);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "ASD Action is required after REQ Status is Assigned");

                //rule 4: PALT Type is required to have different value then "Please Select" (I put the rule 4 here becuase it have same condition)
                controlToBeValidated = jQuery("select[title='" + ASD__Enum_Field.PALT_TYPE + "']");
                isValidated = !ASD_CustomValidation.isSelectedInDropdownEqual(controlToBeValidated, ASD_Enum_FieldChoice.PLEASE_SELECT);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "PALT Type is required after REQ Status is Assigned");

                //rule 5: Contract Specialist Assigned is required from REQ Status is assigned
                controlToBeValidated = jQuery("div[title='" + ASD__Enum_Field.CONTRACT_SPECIALIST_ASSIGNED + "']").find("input:first");
                isValidated = ASD_CustomValidation.isPeoplePickerHasValue(controlToBeValidated);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, true, isValidated, validationResult, "Contract Specialist Assigned is required after REQ Status is Assigned");

                //rule 6: Current Contractor Name is required from REQ Status is assigned (textbox)                
                //controlToBeValidated = jQuery("input[title='" + ASD__Enum_Field.CURRENT_CONTRACTOR_NAME + "']");
                //isValidated = ASD_CustomValidation.isTextBoxHasValue(controlToBeValidated);
                //ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "Current Contractor Name is required after REQ Status is Assigned");
            }
        }

        //rule 7: if ASD Action is "Solicitation Closed", Solicitation Closed Date is required
        ifValue = "";
        ifValue = jQuery("select[title='" + ASD__Enum_Field.ASD_ACTION + "'] option:selected").text();
        if (ifValue) {
            if (ifValue.localeCompare(ASD_Enum_FieldChoice.SOLICITATION_CLOSED) === 0) {
                //ifvalue equals "Solicitation Closed"                
                controlToBeValidated = jQuery("input[title='" + ASD__Enum_Field.SOLICITATION_CLOSE_DATE + "']");
                isValidated = ASD_CustomValidation.isTextBoxHasValue(controlToBeValidated);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "if ASD Action is 'Solicitation Closed', Solicitation Closed Date is required");
            }
        }

        //rule 8:Reasoning is required when request is Cancel
        //If REQ Status = Submittted or Assigned and userAction = "Cancel", then Reasoning is required(based on the state machine workflow)        
        if ((REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.SUBMITTED) === 0) || (REQSTATUS.localeCompare(ASD_Enum_REQ_STATUS.ASSIGNED) === 0)) {
            var userAction = jQuery("input[title='" + ASD__Enum_Field.USER_ACTION + "']").val();//get user Action from hidden textbox(set value when user click specific button)            
            if (userAction.localeCompare(ASD_Enum_User_Action.CANCEL) === 0) {
                //User click on Cancel, now reasoning is require (Textarea)                
                controlToBeValidated = jQuery("textarea[title='" + ASD__Enum_Field.REASONING + "']");
                isValidated = ASD_CustomValidation.isTextBoxHasValue(controlToBeValidated);
                ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "Reasoning is required when Cancelling a request");
            }
        }

        //rule 9: Solicitation # should have format of FERC-abc123 and less than or equal 20 alpha characters.                
        
        controlToBeValidated = jQuery("input[title='" + ASD__Enum_Field.SOLICITATION_NUMBER + "']");
        ifValue = controlToBeValidated.val();
        if (ifValue) {//only check if ifValue is exist (it means controls exist, but jquery control always exist so we can not check on the control)
            Regex = "^(FERC-)[a-zA-Z0-9]{0,15}$";//match FERC-abc123, require to have 'FERC-' and maximum 20 characters
            isValidated = ASD_CustomValidation.isTextBoxMatchValue(controlToBeValidated, Regex);            
            ASD_CustomValidation.setValidationResult(controlToBeValidated, false, isValidated, validationResult, "'SOLICITATION #' must have value of 'FERC-abc' and less than or equal 20 alphanumeric characters");
        }


        //rule 10: User must attach required documents        
        attachedDocument = jQuery("#idAttachmentsTable tr");
        isValidated = attachedDocument.length > 0;
        ASD_CustomValidation.setValidationResult(null, false, isValidated, validationResult, "Attached document(s) required");

    },
};