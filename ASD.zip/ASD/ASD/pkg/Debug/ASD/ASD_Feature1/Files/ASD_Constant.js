﻿/*jshint -W098*//*remove the warning 'variable is defied but never used'*/

/*jshint -W097*//*remove the warning 'use the function form of 'use strict''*/"use strict";

var ASD__Enum_ContentType = Object.freeze({
    ADMINISTRATIVE: "Administrative",
    CHANGE_ORDER_SUPPLEMENTAL_AGREEMENT: "Change Order - Supplemental Agreement",
    EXERCISING_AN_OPTION_YEAR: "Exercising an Option Year",
    FUNDING: "Funding",
    IN_HOUSE_STRATEGIC_BPA_CALL: "In-House Strategic BPA Call",
    PRODUCT: "Product",
    PRODUCT_WITH_INCIDENTAL_SERVICES: "Product With Incidental Services",
    SERVICES: "Services"
});

var ASD__Enum_Field = Object.freeze({
    IS_THIS_AN_IT_PRODUCT_SERVICE: "Is this an IT product/service?",
    IF_REQUESTED_FUNDED_OUTSIDE_OF_CIO_PLEASE_IDENTIFY_YOUR_CIO_POINT_OF_CONTACT: "If Requested/Funded Outside of CIO, please identify your CIO Point of Contact",
    HAVE_YOU_REQUESTED_THIS_PRODUCT_SERVICE_BEFORE: "Have you requested this product/service before?",
    PREVIOUS_CONTRACT_NUMBER: "Previous Contract Number",
    PREVIOUS_CONTRACTOR_NAME:   "Previous Contractor Name",
    REQ_STATUS: "REQ STATUS",
    ASD_ACTION: "ASD Action",
    PALT_TYPE: "PALT Type",
    CONTRACT_SPECIALIST_ASSIGNED: "Contract Specialist Assigned",
    SOLICITATION_CLOSE_DATE: "Solicitation Close Date",
    CURRENT_CONTRACTOR_NAME: "Current Contractor Name",
    REASONING: "Reasoning",
    USER_ACTION: "User Action",
    SOLICITATION_NUMBER: "Solicitation #",
});

var ASD_Enum_FieldChoice = Object.freeze({
    YES_REQUESTED_FUNDED_BY_CIO: "Yes (Requested/Funded by CIO)",
    PLEASE_SELECT: "-- Please Select --",
    SOLICITATION_CLOSED: "SOLICITATION CLOSED",
});

var ASD_Enum_REQ_STATUS = Object.freeze({
    DRAFT : "DRAFT",
    SUBMITTED: "SUBMITTED",
    REJECTED : "REJECTED",
    INCOMPLETE: "INCOMPLETE",
    AO_APPROVED: "AO APPROVED",
    IN_REVIEW: "IN REVIEW",
    CANCEL_BY_REQUESTOR: "CANCEL BY REQUESTOR",
    REQUIREMENT_CANCEL: "REQUIREMENT CANCEL",
    ASSIGNED: "ASSIGNED",
    ON_HOLD: "ON HOLD",
    AWARD: "AWARD"
});

var ASD_Enum_User_Action = Object.freeze({
    CANCEL: "CANCEL",
});

var ASD_Enum_Group = Object.freeze({
    ASD_Admin: "ASD Admin",
    CO_Group: "CO",
});

var ASD_Enum_Role = Object.freeze({
    SUBMITTING_OFFICE: "Submitting Office",
    END_USER: "End User",
    AO_COR: "AO/COR",
    CO: "CO",
    CS: "CS"
});