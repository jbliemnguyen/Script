﻿/*jshint -W098*//*remove the warning 'variable is defied but never used'*/

/*jshint -W097*//*remove the warning 'use the function form of 'use strict''*/
///<reference path="ASD_Constant.js" />
"use strict";
var currentLoginPermissionLevel = {
    BelongsToSubmittingOffice: false,
    IsCreator: false,
    isAO: false,
    isCOR: false,
    BelongsToCOGroup: false,
    isCS: false,
    BelongsToEndUserGroup: false,
    //method to reset the object to its initial state
    populateData: function () {
        var userId = _spPageContextInfo.userId;
        var siteURL = _spPageContextInfo.siteAbsoluteUrl;
        var serverRequestPath = _spPageContextInfo.serverRequestPath;
        //if newform.aspx, creator
        if (serverRequestPath.indexOf("NewForm.aspx") > -1) {
            this.BelongsToSubmittingOffice = false;//does not know yet when user first create the form
            this.IsCreator = true;
            this.isAO = false;//does not know yet when user first create the form
            this.isCOR = false;//does not know yet when user first create the form
            this.BelongsToCOGroup = false;//does not know yet when user first create the form
            this.isCS = false;//does not know yet when user first create the form
            this.BelongsToEndUserGroup = false;//does not know yet when user first create the form
            return;
        } else {
            if (serverRequestPath.indexOf("EditForm.aspx") > -1) {//edit form
                var LoginUserName = this.getLoginUserName(siteURL, userId);
                //get object from javascript object        
                var ListData = WPQ2FormCtx.ListData;

                //set the field "BelongstoSubmittingOffice"
                var SubmittingOffice = ListData.Submitting_x0020_Office;
                this.BelongsToSubmittingOffice = this.DoesUserBelongsToGroup(siteURL, userId, SubmittingOffice);

                //Set the field "IsCreator"
                var authorName = ListData.Author;//"2;#Liem Nguyen,#i:0#.w|adferc\\lnguyen,#,#,#Liem Nguyen"
                authorName = authorName.split('|')[1].split(',')[0];
                this.IsCreator = (authorName.localeCompare(LoginUserName) === 0);
                if (ListData.Authorization_x0020_Official) {
                    var AOUserName = ListData.Authorization_x0020_Official[0].Key.split("|")[1];//only 1 people allowed in COR field                    
                    this.isAO = (AOUserName.localeCompare(LoginUserName) === 0)
                }


                //set the field IsCOR
                if (ListData.COR) {
                    var CORUserName = ListData.COR[0].Key.split("|")[1];//required field, no need to check if value exist - only 1 people allowed in COR field                    
                    this.isCOR = (CORUserName.localeCompare(LoginUserName) === 0);
                }

                //Set the field BelongsToCOGroup
                this.BelongsToCOGroup = this.DoesUserBelongsToGroup(siteURL, userId, ASD_Enum_Group.CO_Group);

                //Set the field IsCS
                if (ListData.Contract_x0020_Specialist_x0020_) {
                    var ContractSpecialistAssigned = ListData.Contract_x0020_Specialist_x0020_[0].Key.split("|")[1];                    
                    this.isCS = (ContractSpecialistAssigned.localeCompare(LoginUserName) === 0);
                }

                //Set the field "BelongToEndUserGroup"
                if (ListData.End_x0020_User) {
                    var EndUserGroup = ListData.End_x0020_User;
                    this.BelongsToEndUserGroup = this.DoesUserBelongsToGroup(siteURL, userId, EndUserGroup)
                }
                
            } else {
                alert("UnKnown Form Type");
            }
        }





    },

    //*********************************************************************
    //determine if current login user belongs to group. CSOM have this built -in functions, but this is for rest api call.
    DoesUserBelongsToGroup: function (siteURL, userId, groupName) {
        try {
            var returnValue = false;
            $.ajax({
                async: false,
                url: siteURL + "/_api/web/sitegroups()?$select=id&$filter=(Title eq '" + groupName + "')",
                method: "GET",
                headers: {
                    "accept": "application/json; odata=verbose"
                },
                success: function (groupData) {
                    var listResults = groupData.d.results;
                    if (listResults.length > 0) {
                        $.ajax({
                            async: false,
                            url: siteURL + "/_api/Web/SiteGroups/GetById(" + listResults[0].Id + ")/Users?$select=Id,Title&$filter=(Id eq " + userId + ")",
                            method: "GET",
                            headers: {
                                "accept": "application/json; odata=verbose"
                            },
                            success: function (userData) {
                                if (userData.d.results.length > 0) {
                                    //alert("user belong to this group " + groupName);
                                    returnValue = true;
                                }
                                else {
                                    //alert("user not belong to group " + groupName);
                                    returnValue = false;
                                }
                            },
                            error: function (err) {
                                // Error
                                alert(JSON.stringify(err));

                            }
                        });
                    }
                },
                error: function (err) {
                    // Error
                    alert(JSON.stringify(err));
                }

            });

            return returnValue;
        }
        catch (err) {
            alert(JSON.stringify(err));
        }
    },

    //*********************************************************************
    //make rest api call to get login user name
    getLoginUserName: function (siteURL, UserId) {
        var returnValue;
        jQuery.ajax({
            async: false,//login must be ready for further processing, 
            url: siteURL + "/_api/Web/GetUserById(" + UserId + ")",
            type: "GET",
            headers: { "Accept": "application/json;odata=verbose" },
            success: function (data) {
                var dataResults = data.d;
                //get login name    
                returnValue = dataResults.LoginName.split('|')[1];
            }

        });
        return returnValue;//return value should be return here, not above, or it will have undefine value??? don't know why
    }
};
